@extends('main')
@section('title','| About page')
@section('content')
    <div class="row">
        <div class="col-md-12">
            <h1>About me</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab autem cumque facilis illo, nesciunt possimus
                quidem quod rem? Alias consectetur delectus deleniti esse est exercitationem ipsum officia ratione,
                repudiandae vel?</p>
        </div>
    </div>
@endsection