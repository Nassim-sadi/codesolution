<?php $__env->startSection('title','| About page'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h1>About me</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab autem cumque facilis illo, nesciunt possimus
                quidem quod rem? Alias consectetur delectus deleniti esse est exercitationem ipsum officia ratione,
                repudiandae vel?</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>