<?php $__env->startSection('title','| Home page'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="jumbotron">
                <h1>Welcome to my blog!</h1>
                <p>Thanks for visiting My blog ,this site is made with laravel 5.6 i hope you enjoy your visit</p>
                <p><a class="btn btn-primary btn-lg" href="#" role="button">popular post</a></p>
            </div>
        </div>

    </div>
    <div class="row">
        <div class="col-md-8">
            <div class="post">
                <h3>Post Title</h3>
                <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                    et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                    aliquip ex ea commodo consequat. Duis aute irure d...</p>
                <a href="#" class="btn btn-primary">Read-more</a>
            </div>
            <hr>
            <div class="post">
                <h3>Post Title</h3>
                <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                    et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                    aliquip ex ea commodo consequat. Duis aute irure d...</p>
                <a href="#" class="btn btn-primary">Read-more</a>
            </div>
            <hr>
            <div class="post">
                <h3>Post Title</h3>
                <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                    et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                    aliquip ex ea commodo consequat. Duis aute irure d...</p>
                <a href="#" class="btn btn-primary">Read-more</a>
            </div>
            <hr>
            <div class="post">
                <h3>Post Title</h3>
                <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                    et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                    aliquip ex ea commodo consequat. Duis aute irure d...</p>
                <a href="#" class="btn btn-primary">Read-more</a>
            </div>
        </div>
        <hr>
        <div class="col-md-3 col-md-offset-1">
            <h2>Side Bar</h2>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>